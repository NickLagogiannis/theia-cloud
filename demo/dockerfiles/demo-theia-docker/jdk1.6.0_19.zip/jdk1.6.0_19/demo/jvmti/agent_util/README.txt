#
# @(#)README.txt	1.3 06/01/28
#
# Copyright 2006 Sun Microsystems, Inc. All rights reserved.
# SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#

agent_util sources: @(#)README.txt	1.3 06/01/28

Just some shared generic source used by several of the demos.

